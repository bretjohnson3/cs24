unsigned char * rl_decode(unsigned char *input_data, int input_length,
                          int *output_length);

