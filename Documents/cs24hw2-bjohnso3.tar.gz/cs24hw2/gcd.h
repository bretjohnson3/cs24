/*
 * This is a stub header for gcd.s
 */
extern int gcd(int m, int n);
